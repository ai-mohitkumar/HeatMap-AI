# HeatShield AI — Complete Master Offline Research Suite
Version 2.0.4 | SIH26083

This archive contains the entire standalone offline ecosystem:
- Full Python Machine Learning Pipeline (K-Means, GMM, PCA, UMAP, Isolation Forest, Markov Transition Matrix).
- All 46 NOAA GSOD synoptic weather stations with multi-year quality-filtered data.
- Complete 787 Indian districts and 650,000 villages geographic dictionary with 4-station IDW interpolation.
- Full React 19 + TypeScript + Vite web client source code.
- Pre-built Android APK, Apple iOS Profile, and Wear OS companion.
