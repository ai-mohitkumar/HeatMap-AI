# HeatShield AI — Desktop Standalone Command Center
## Version 2.0.6 (Windows, macOS, Linux)

### Instant 1-Click Launch:
1. **Extract ALL files** from this ZIP archive first (do not launch inside ZIP preview).
2. **Windows:** Double-click `HeatShield-AI.bat`.
   - Uses Python if installed, or automatically falls back to Windows' built-in PowerShell server (`server.ps1`) — zero extra installation needed.
3. **macOS / Linux:** Open Terminal in the extracted folder and run `./launch-mac-linux.sh`.
4. Note: Do **not** open `web/index.html` directly via `file://` because modern browsers block interactive JS modules and maps on raw `file://` URLs.

### Features Included:
- Hybrid Live + Offline Vector Map: automatically fails over across CARTO Dark / CARTO Voyager / Esri World Street / OSM tiles when online, and renders an crisp built-in India/world vector map offline.
- All 46 synoptic stations with multi-year observations (2022–2025).
- Continuous 4-station IDW spatial interpolation engine (<0.6ms execution).
- All 787 districts and 650,000 villages directory.
- Complete Research & Viva Defense Lab (RQ1–RQ6).
