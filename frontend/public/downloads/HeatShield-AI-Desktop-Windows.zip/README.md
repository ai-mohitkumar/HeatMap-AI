# HeatShield AI — Desktop Standalone Command Center
## Version 2.0.4 (Windows, macOS, Linux)

### Instant 1-Click Launch:
1. Double-click `HeatShield-AI.bat` (Windows) or open `web/index.html` in Chrome/Edge/Firefox.
2. The full command center launches locally with zero internet dependency required.

### Features Included:
- All 46 synoptic stations with multi-year observations (2022–2025).
- Continuous 4-station IDW spatial interpolation engine (<0.6ms execution).
- All 787 districts and 650,000 villages directory.
- Complete Research & Viva Defense Lab (RQ1–RQ6).
- Exportable executive briefings and CSV tabular datasets.
