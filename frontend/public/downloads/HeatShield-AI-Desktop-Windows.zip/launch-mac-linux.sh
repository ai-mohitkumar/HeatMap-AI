#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "==================================================================="
echo "            HeatShield AI - Desktop Command Center"
echo "==================================================================="
if command -v python3 >/dev/null 2>&1; then
  exec python3 "$SCRIPT_DIR/server.py"
elif command -v python >/dev/null 2>&1; then
  exec python "$SCRIPT_DIR/server.py"
else
  echo "Python 3 is required on macOS/Linux. Install Python 3 or run:"
  echo "  python3 -m http.server 18573 --directory "$SCRIPT_DIR/web""
  exit 1
fi
