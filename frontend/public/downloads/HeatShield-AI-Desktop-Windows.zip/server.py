#!/usr/bin/env python3
"""Zero-race local loopback HTTP server for HeatShield AI Desktop Standalone."""
import functools
import http.server
import os
import socketserver
import threading
import webbrowser


class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class HeatShieldHandler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".js": "application/javascript; charset=utf-8",
        ".mjs": "application/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".svg": "image/svg+xml",
        ".json": "application/json; charset=utf-8",
        ".webmanifest": "application/manifest+json; charset=utf-8",
        ".png": "image/png",
        ".ico": "image/x-icon",
    }

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def do_GET(self):
        clean_path = self.path.split("?", 1)[0].split("#", 1)[0]
        if clean_path.startswith("/api/"):
            body = b'{"error":"offline_local_bundle","offline":true}'
            self.send_response(404)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        super().do_GET()

    def log_message(self, format, *args):
        pass


def main():
    web_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
    handler = functools.partial(HeatShieldHandler, directory=web_dir)

    httpd = None
    chosen_port = None
    for candidate in list(range(18573, 18596)) + [0]:
        try:
            httpd = ThreadingTCPServer(("127.0.0.1", candidate), handler)
            chosen_port = httpd.server_address[1]
            break
        except OSError:
            continue

    if httpd is None or chosen_port is None:
        raise RuntimeError("Could not bind any local loopback port for HeatShield AI.")

    url = f"http://127.0.0.1:{chosen_port}/"
    print(f"[OK] HeatShield AI local server listening at {url}")
    print("[*] Press Ctrl+C in this window when finished to stop the server.")
    threading.Timer(0.25, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Shutting down HeatShield AI server...")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
