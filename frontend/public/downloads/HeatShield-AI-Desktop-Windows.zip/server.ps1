$ErrorActionPreference = 'Stop'
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$webRoot = [System.IO.Path]::GetFullPath((Join-Path $scriptDir 'web'))

if (-not (Test-Path $webRoot)) {
    Write-Error "Web assets directory missing: $webRoot"
    exit 1
}

$mimeTypes = @{
    '.html' = 'text/html; charset=utf-8'
    '.htm'  = 'text/html; charset=utf-8'
    '.js'   = 'application/javascript; charset=utf-8'
    '.mjs'  = 'application/javascript; charset=utf-8'
    '.css'  = 'text/css; charset=utf-8'
    '.json' = 'application/json; charset=utf-8'
    '.webmanifest' = 'application/manifest+json; charset=utf-8'
    '.svg'  = 'image/svg+xml'
    '.png'  = 'image/png'
    '.jpg'  = 'image/jpeg'
    '.jpeg' = 'image/jpeg'
    '.ico'  = 'image/x-icon'
    '.woff2' = 'font/woff2'
    '.woff' = 'font/woff'
    '.ttf'  = 'font/ttf'
}

$listener = $null
$baseUrl = $null
foreach ($port in 18573..18595) {
    $candidate = New-Object System.Net.HttpListener
    $prefix = "http://127.0.0.1:$port/"
    $candidate.Prefixes.Add($prefix)
    try {
        $candidate.Start()
        $listener = $candidate
        $baseUrl = $prefix
        break
    } catch {
        try { $candidate.Close() } catch {}
    }
}

if (-not $listener) {
    Write-Error "Unable to start local HTTP server on ports 18573-18595."
    exit 1
}

Write-Host "[OK] HeatShield AI local server running at $baseUrl"
Write-Host "[*] Keep this window open while using HeatShield AI (Ctrl+C to quit)."
Start-Process $baseUrl

try {
    while ($listener.IsListening) {
        try {
            $ctx = $listener.GetContext()
        } catch {
            break
        }
        try {
            $reqPath = $ctx.Request.Url.AbsolutePath
            if ($reqPath -like '/api/*') {
                $errBytes = [System.Text.Encoding]::UTF8.GetBytes('{"error":"offline_local_bundle","offline":true}')
                $ctx.Response.StatusCode = 404
                $ctx.Response.ContentType = 'application/json; charset=utf-8'
                $ctx.Response.ContentLength64 = $errBytes.Length
                $ctx.Response.OutputStream.Write($errBytes, 0, $errBytes.Length)
                $ctx.Response.OutputStream.Close()
                continue
            }

            $rel = $reqPath.TrimStart('/')
            if ([string]::IsNullOrWhiteSpace($rel)) { $rel = 'index.html' }
            $safeRel = $rel -replace '/', [System.IO.Path]::DirectorySeparatorChar
            $target = [System.IO.Path]::GetFullPath((Join-Path $webRoot $safeRel))

            if (-not $target.StartsWith($webRoot, [System.StringComparison]::OrdinalIgnoreCase)) {
                $ctx.Response.StatusCode = 403
                $ctx.Response.OutputStream.Close()
                continue
            }

            if (-not (Test-Path $target -PathType Leaf)) {
                if (-not [System.IO.Path]::HasExtension($target)) {
                    $target = Join-Path $webRoot 'index.html'
                }
            }

            if (-not (Test-Path $target -PathType Leaf)) {
                $ctx.Response.StatusCode = 404
                $ctx.Response.OutputStream.Close()
                continue
            }

            $ext = [System.IO.Path]::GetExtension($target).ToLowerInvariant()
            $mime = if ($mimeTypes.ContainsKey($ext)) { $mimeTypes[$ext] } else { 'application/octet-stream' }
            $bytes = [System.IO.File]::ReadAllBytes($target)
            $ctx.Response.StatusCode = 200
            $ctx.Response.ContentType = $mime
            $ctx.Response.Headers['Cache-Control'] = 'no-cache'
            $ctx.Response.ContentLength64 = $bytes.Length
            $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
            $ctx.Response.OutputStream.Close()
        } catch {
            try { $ctx.Response.Abort() } catch {}
        }
    }
} finally {
    $listener.Stop()
    $listener.Close()
}
