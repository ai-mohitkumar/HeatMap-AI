@echo off
title HeatShield AI - Desktop Command Center
echo ===================================================================
echo             HeatShield AI - Desktop Command Center
echo   Unsupervised Spatiotemporal Climate Intelligence Platform
echo                 Project No. 25 - SIH26083
echo ===================================================================
echo.
echo Starting local offline high-performance HTTP web server...
cd /d "%~dp0"
start "" "http://localhost:5173"
python -m http.server 5173 --directory web
if %errorlevel% neq 0 (
    echo Python not found in PATH, launching standalone web viewer directly...
    start "" "%~dp0web\index.html"
)
pause
