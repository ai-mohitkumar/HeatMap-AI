@echo off
setlocal
title HeatShield AI - Desktop Command Center
echo ===================================================================
echo             HeatShield AI - Desktop Command Center
echo   Unsupervised Spatiotemporal Climate Intelligence Platform
echo                 Project No. 25 - SIH26083
echo ===================================================================
echo.
cd /d "%~dp0"

where python >nul 2>nul
if %errorlevel% equ 0 (
    echo Starting local HTTP server via Python...
    python "%~dp0server.py"
    goto :done
)

where py >nul 2>nul
if %errorlevel% equ 0 (
    echo Starting local HTTP server via Python Launcher...
    py -3 "%~dp0server.py"
    goto :done
)

echo Python not detected; starting built-in Windows PowerShell local server...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"

:done
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Local server could not start automatically.
    echo Ensure you extracted ALL files from the ZIP archive before launching.
    pause
)
